Arduino Cloud historic data

variables:
  - id: 33c70c4e-bbb1-411e-a925-8fd395b9fa0d
    name: Temperature
    thingName: IoT_Zaria_Sensor
  - id: 5261a99f-e7ef-4e47-a6f7-d7bb79c2eb93
    name: Humidity
    thingName: IoT_Zaria_Sensor
from: 2024-02-22T00:45:14Z
to: 2024-02-23T23:59:59Z

Have fun! :)
